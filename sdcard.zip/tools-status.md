# Narzędzia Momentum na T-Embed

Nowe narzędzia są w `apps/Tools`, aplikacje Bluetooth w `apps/Bluetooth`.
Skopiuj foldery `apps` i `apps_assets` na SD z zachowaniem istniejących aplikacji.
Potrzebny jest również nowy firmware przygotowany razem z paczką.

21 aplikacji przebudowano dla ESP32-S3 i sprawdzono ich zależności.
Nie oznacza to przetestowania wszystkich funkcji na fizycznym urządzeniu.
BT Trigger i PC Monitor zostały usunięte z paczki na życzenie użytkownika.

Nie dołączono niedziałających plików:

- CLI-GUI Bridge: wymaga starszego wewnętrznego interfejsu CLI Flippera.
- DTMF Dolphin: wymaga przeniesienia syntezy dźwięku z DMA STM32 do I2S ESP32.
- uPython: własny system kompilacji i środowisko ARM wymagają osobnego portu.
- Quac!: zależności od nieprzeniesionego iButton i innych interfejsów sprzętowych.
- Tasks: niezgodność nagłówków i biblioteki standardowej C++.
- FlipBIP: brakuje implementacji części funkcji kryptograficznych; nie używać
  niezweryfikowanego portu do przechowywania prawdziwych środków ani kluczy.
- IconEdit: wymaga interfejsu kodowania kompresji nowszego niż w tym porcie.
- Tone Generator: nieprzeniesiona kompilacja animowanych ikon.

NFC/RFID Detector i Authenticator/TOTP już istnieją w porcie, nie zastępowano ich.
8 października 2026 dodano dostarczony przez użytkownika `ble_spam.fap`
do `apps/Bluetooth`. Plik ma architekturę Xtensa; nie był przebudowywany
ani testowany na urządzeniu i nie jest objęty powyższym raportem 21 narzędzi.

Pełny wynik: `tools-build-report.csv`. Weryfikacja: `tools-verification.json`.
Źródła i licencje zachowano w `../applications_user/momentum_tools`.
